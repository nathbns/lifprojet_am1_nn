"use client";

import { useState } from "react";
import { GlowingEffect } from "@/components/ui/glowing-effect";

export default function TestPage() {
  const [switchOn, setSwitchOn] = useState(false);
  const [selectValue, setSelectValue] = useState("1");

  return (
    <main className="min-h-screen bg-gray-900 flex flex-col items-center justify-center gap-10 p-8 text-white">

      <h1 className="text-3xl font-bold">Test Page</h1>

      {/* Select interactif */}
      <div className="relative z-20">
        <label htmlFor="mySelect" className="mr-2">Choisir une option :</label>
        <select
          id="mySelect"
          value={selectValue}
          onChange={(e) => setSelectValue(e.target.value)}
          className="text-black px-2 py-1 rounded"
        >
          <option value="1">Option 1</option>
          <option value="2">Option 2</option>
          <option value="3">Option 3</option>
        </select>
      </div>


      {/* Switch interactif */}
      <div className="relative z-20 flex items-center gap-2">
        <label htmlFor="mySwitch">Activer le switch :</label>
        <input
          type="checkbox"
          id="mySwitch"
          checked={switchOn}
          onChange={() => setSwitchOn(!switchOn)}
          className="w-12 h-6 rounded-full appearance-none bg-gray-700 checked:bg-green-500 transition-colors relative cursor-pointer"
        />
      </div>

      {/* Conteneur avec GlowingEffect */}
      <div className="relative w-64 h-64 rounded-xl bg-gray-800 flex items-center justify-center">
        <p className="z-30 relative text-xl font-bold">Hello ✨</p>

        {/* GlowingEffect derrière le texte */}
        <GlowingEffect glow={true} disabled={false} blur={20} spread={30} className="z-10" />
      </div>

    </main>
  );
}

