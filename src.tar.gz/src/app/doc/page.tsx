

export default function Docs () {
    return (
        <main>
        </main>
    )
}