"use client";
import { Button } from "@/components/ui/button";
import { FileUpload } from "@/components/ui/file-upload";
import { useState } from "react";
import { TextRevealButton } from "@/components/ui/shadcn-io/text-reveal-button";

export default function Ai() {
    const [ai, setAi] = useState()

    return (
        <main className="p-10">
            <h1>{ai}</h1>
            <div className="m-4 flex justify-around">
                <Button onClick={() => setAi("text")}>Text AI</Button>
                <Button onClick={() => setAi("car")}>Car AI</Button>
            </div>
            <div className="border border-10 w-full flex flex-col justify-center items-center">
                <FileUpload/>
            <TextRevealButton className="m-4" text="Calculate!"/>
            </div>
        </main>
    )
}