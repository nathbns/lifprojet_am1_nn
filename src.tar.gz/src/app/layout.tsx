import "./globals.css";

import Image from "next/image";
import Navbar04Page from '@/components/navbar-04/navbar-04';

export const metadata = {
  title: "Driving Controller",
  description: "Detects elements on the road with AI",
  icons: {
    icon: "car-icon.svg",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="bg-stone-800">
      <body className="min-h-screen flex flex-col bg-stone-50">
        <header className="rounded-full bg-pink-300 text-center w-300 m-5 pt-2 pb-2 self-center">
          <h1 className="text-5xl text-white font-semibold">{metadata.title}</h1>
          <h2 className="text-xl">{metadata.description}</h2>
        </header>
        <Navbar04Page/>          
          {children}
        <footer className="bg-stone-800 text-white text-center bottom-0 p-5">
          <p className="mb-2">Made with by <Image src="heart.svg" alt="heart" width={20} height={20} className="inline"/> Nathan and Mehdi</p>
        </footer>
      </body>
    </html>
  );
}
