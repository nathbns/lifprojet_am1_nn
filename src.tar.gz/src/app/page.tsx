"use client"
import { useState, useRef} from "react";

export default function Home() {
  const [error, setError] = useState<string | null>(null)
  const [answer, setAnswer] = useState("")
  const fileInputRef = useRef<HTMLInputElement | null>(null) // file reference

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Taille max = 2 Mo
    const maxSize = 2 * 1024 * 1024 
    if (file.size > maxSize) {
      setError("The file is too large (max 2 Mo).")
      if (fileInputRef.current) fileInputRef.current.value = ""
      return
    }

    // Formats autorisés
    const allowedTypes = ["image/jpeg"]
    if (!allowedTypes.includes(file.type)) {
      setError("Format unsupported (JPEG only).")
      if (fileInputRef.current) fileInputRef.current.value = ""
      return
    }

    setError(null)
    console.log("Fichier accepté :", file.name, "(", file.type, ")")
  }

  const updateAnswer = () => {
    if (!fileInputRef.current || !fileInputRef.current.value) {
      setError("There is no current image to detect any text...")
      return
    }

    else {
      setError(null)
      setAnswer("This is a text")
      return
    }
  }



  return (
    <main>
      <form className="p-3">
        <label htmlFor="file" className="text-2xl">Please upload a file:</label>
        <input type="file" id="file" name="file" onChange={handleFileChange} ref={fileInputRef} className="block border border-dashed border-blue-900"/>
              {error && <p className="text-red-600">{error}</p>}
        <button type="button" onClick={updateAnswer} className="border rounded-full p-1 bg-stone-200 inline-block hover:bg-stone-400">Submit</button>
      </form>
      <section>
        {answer && <p>{answer}</p>}
      </section>
    </main>
  );
}
