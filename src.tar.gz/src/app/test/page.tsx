"use client";

import CountUp from '../../components/CountUp';
import Stepper from '../../components/Stepper';
import { FileUpload } from '@/components/ui/file-upload';
import { Switch } from '@/components/ui/switch';
import { LoaderOne } from '@/components/ui/loader';
import { useState } from 'react';
import { GlowingEffect } from '@/components/ui/glowing-effect';

export default function Test() {
    const [check, setCheck] = useState(false)

    return (
        <main>
                
            <Switch checked={check}
                onCheckedChange={setCheck} className="z-99"
            />
            <h1>{check.toString()}</h1>
            <CountUp from={0} to={100} separator=" " direction="up" duration={2}/>
            <div className="border border-10 w-full flex justify-center items-center">
                <FileUpload/>
            </div>
            <LoaderOne/>
            <p>jde</p>
            <p>jde</p>


            <Stepper steps={['Step 1', 'Step 2', 'Step 3']} initialStep={1}>
                <div>
                    <p>This is the content of Step 1</p>
                </div>

                <div>
                    <p>This is the content of Step 2</p>
                </div>
                <div>
                    <p>This is the content of Step 3</p>
                </div>
            </Stepper>
        </main>
    )
}