"use client"

import { useTheme } from "next-themes";
import { Switch } from "@/components/ui/switch";

export default function DarkLightMode() {
    const { theme, setTheme, resolvedTheme } = useTheme();
    // Switch checked si le thème est dark, sinon false
    const isDark = resolvedTheme === "dark";

    {/*if (!resolvedTheme) {
        return <div>Chargement du thème…</div>;
    }*/}

    return (
        <>
            <div className="relative flex items-center gap-2 mb-4 z-6">
                <Switch
                    checked={isDark}
                    onCheckedChange={checked => setTheme(checked ? "dark" : "light")} className="z-100"
                />
                <span>{isDark ? "Sombre" : "Clair"}</span>
            </div>
            <div className={
                isDark
                    ? "border border-white bg-black text-white p-4 mt-4"
                    : "border border-black bg-white text-black p-4 mt-4"
            }>
                <h1>Je change de couleur !</h1>
                <p>Thème actuel : {resolvedTheme}</p>
            </div>
        </>
    )
}